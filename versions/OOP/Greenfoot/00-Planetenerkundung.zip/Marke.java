import greenfoot.*;

/**
 * Eine Markierung, die ein Rover ablegen oder einsammeln kann.
 */
public class Marke extends Actor {

    public Marke() {
        setImage("images/marke.png");
    }

    /**
     * Act-Methode der Marke.
     */
    public void act() {
        // Die Marke hat keine Funktion.
    }

}
