	
// New exception to throw if mail is not found in mailbox
public class MailNotFoundException extends Exception {};