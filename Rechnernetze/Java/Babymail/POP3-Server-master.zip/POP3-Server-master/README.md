# POP3-Server

<b>Informations :</b>
<table>
  <tr>
    <td><b>Language</b></td>
    <td>Java [8]</td>
  </tr>
  <tr>
    <td><b>IDE</b></td>
    <td>NetBeans [8]</td>
  </tr>
  <tr>
    <td><b>Standard</b></td>
    <td>POP3</td>
  </tr>
  <tr>
    <td><b>SSL/TLS</b></td>
    <td>Yes</td>
  </tr>
</table>

<br>

<b>Based on</b> : http://abcdrfc.free.fr/rfc-vf/rfc1939.html
<br><br>
<b>Related sources : </b><br>
[1] http://abcdrfc.free.fr/rfc-vf/rfc1939.html<br>
[2] http://www.avolio.com/columns/E-mailheaders.html<br>
