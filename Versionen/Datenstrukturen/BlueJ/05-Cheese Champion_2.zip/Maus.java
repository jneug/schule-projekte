/**
 * Eine Maus, die am Mäusekampf (Cheese Champion) teilnimmt, hat eine Nummer
 * und eine Stärke als Attribute.
 */
public class Maus {

    TODO: Implementiere die Maus nach der Beschreibung
    private int nummer;

    private int staerke;

    public Maus( int pNummer, int pStaerke ) {
        // Hier fehlt was
    }

    public int getNummer() {
        // Hier fehlt was
    }

    public int getStaerke() {
        // Hier fehlt was
    }

}
