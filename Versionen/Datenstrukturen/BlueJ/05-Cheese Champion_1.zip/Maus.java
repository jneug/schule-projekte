/**
 * Eine Maus, die am Mäusekampf (Cheese Champion) teilnimmt, hat eine Nummer
 * und eine Stärke als Attribute.
 */
public class Maus {

    TODO: Implementiere die Maus nach der Beschreibung

}
