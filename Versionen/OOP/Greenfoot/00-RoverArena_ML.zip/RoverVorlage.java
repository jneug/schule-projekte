public class RoverVorlage extends Rover {

    protected void roverErstellen() {
        name = "Mark Watney";
    }

    public void act() {
        // Hier programmiert ihr euren Rover.
        // Pro Aufruf von act() darf der Rover zwei Aktionen ausführen.
    }

}
